
package com.proyect1.demo.Errores;

import com.proyect1.demo.Entidades.Autor;
import com.proyect1.demo.Repositorios.AutorRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


public class erroresServicios  extends Exception{
    public erroresServicios(String msn){
        super(msn); 
    }
 
   

   
    
}
   
    