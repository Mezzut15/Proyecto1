package com.proyect1.demo.Repositorios;

import com.proyect1.demo.Entidades.Autor;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AutorRepositorio extends JpaRepository<Autor, String> {

    @Query("SELECT a FROM Autor a WHERE a.nombre = :nombre")
    public Autor BuscarAutor(@Param("nombre") String nombre);


    /*@Query("select a from Libro a where a.nombre LIKE :c ")
    List<Autor> findAllByQ(@Param("a") String a);*/
}
