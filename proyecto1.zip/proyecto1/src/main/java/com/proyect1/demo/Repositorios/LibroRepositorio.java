
package com.proyect1.demo.Repositorios;

import com.proyect1.demo.Entidades.Libro;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface LibroRepositorio extends JpaRepository<Libro, String> {
@Query("SELECT  c FROM Libro c WHERE c.Titulo = :Titulo") 
public Libro BuscarLibro(@Param("Titulo") String Titulo);
/*List<Libro> findAllByQ(@Param("c") String c);
    @Query("select c from Libro c where c.Titulo LIKE :c ")
    List<Libro> findAllByQ(@Param("c") String c);
*/
}

    
   