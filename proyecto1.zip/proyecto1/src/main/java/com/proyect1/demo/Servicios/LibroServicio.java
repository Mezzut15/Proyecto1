package com.proyect1.demo.Servicios;

import com.proyect1.demo.Entidades.Libro;
import com.proyect1.demo.Errores.erroresServicios;
import com.proyect1.demo.Repositorios.LibroRepositorio;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LibroServicio {

    @Autowired
    LibroRepositorio replibro;
    @Autowired
    private AutorServicio Autser;
    @Autowired
    private EditorialServicio EdSer;
@Transactional
    public void CrearLibro(String Titulo, Integer anio, Long isbn, Integer ejemplares, Integer ejemplaresprestados  ) throws Exception {
        Libro libro = new Libro();

        if (Titulo == null || Titulo.isEmpty()) {
            throw new erroresServicios("El nombre del libro no es valido o esta vacio");

        } else {
            libro.setTitulo(Titulo);
            libro.setAlta(Boolean.TRUE);
            libro.setAnio(anio);
            libro.setEjemplares(ejemplares);
            libro.setIsbn(isbn);
            libro.setEjemplaresPrestados(ejemplaresprestados);
            
           /// libro.setEjemplaresRestantes(Integer.MAX_VALUE);

            replibro.save(libro);
        }

    }
@Transactional
    public void ModificarLibro(String idLibro, String Titulo) throws Exception {
        Libro libro = replibro.findById(idLibro).get();
        if (Titulo == null || Titulo.isEmpty()) {
            throw new erroresServicios("el libro no se encuentra en la lista");
        } else {
            
            libro.setTitulo(Titulo);
            libro.setAlta(Boolean.TRUE);

            replibro.save(libro);
        }
    }
@Transactional
    public void eliminarlibro(String idAutor, String Titulo) throws Exception {
        Libro libro = replibro.findById(idAutor).get();
        if (libro == null) {
            throw new erroresServicios("el libro no se encuentra en la lista");
        } else {
            replibro.save(libro);
        }
    }

}
