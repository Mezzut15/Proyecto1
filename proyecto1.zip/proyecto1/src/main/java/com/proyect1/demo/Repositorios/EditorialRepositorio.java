
package com.proyect1.demo.Repositorios;

import com.proyect1.demo.Entidades.Editorial;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface EditorialRepositorio extends JpaRepository<Editorial, String>{
@Query("SELECT e FROM Editorial e WHERE e.nombre = :nombre") 
public Editorial BuscarEditorial (@Param("nombre") String nombre);    

   /* @Query("select e from Libro e where e.nombre LIKE :e ")
    List<Editorial> findAllByQ(@Param("e") String e);
*/
} 
    

