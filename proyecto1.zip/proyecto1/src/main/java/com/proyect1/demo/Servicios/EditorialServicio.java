
package com.proyect1.demo.Servicios;

import com.proyect1.demo.Entidades.Editorial;
import com.proyect1.demo.Errores.erroresServicios;
import com.proyect1.demo.Repositorios.EditorialRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EditorialServicio {
     @Autowired
   EditorialRepositorio repEditorial;
     
     
     public void CrearEditorial(String nombre) throws  Exception {  
    Editorial editorial = new Editorial();
   
    if (nombre == null || nombre.isEmpty()){
        throw new erroresServicios("El nombre de la editorial no es valido o esta vacio");
    } else{
        editorial.setNombre(nombre);
        editorial.setAlta(Boolean.TRUE);
        
        repEditorial.save(editorial);
    }
}
   public void ModificarEditorial(String idEditorial,  String nombre) throws  Exception{
        Editorial editorial = repEditorial.findById(idEditorial).get();
        if (nombre == null || nombre.isEmpty()){
        throw new erroresServicios("el nombre de la editorial no se encuentra en la lista");
    } else{
        editorial.setNombre(nombre);
        editorial.setAlta(Boolean.TRUE);
        
        repEditorial.save(editorial);
    }
   }
    public void eliminarEditorial(String idEditorial) throws  Exception{
       Editorial editorial = repEditorial.findById(idEditorial).get();
        if ( editorial == null){
        throw new erroresServicios("el nombre de la editorial no se encuentra en la lista");
    } else{
        repEditorial.save(editorial);
    }
   }
}
