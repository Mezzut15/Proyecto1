package com.proyect1.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibroApplication {

    public static void main(String[] args) {
        SpringApplication.run(LibroApplication.class, args);
    }

}
