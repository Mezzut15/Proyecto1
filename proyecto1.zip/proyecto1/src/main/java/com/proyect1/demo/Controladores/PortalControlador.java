package com.proyect1.demo.Controladores;

import com.proyect1.demo.Servicios.AutorServicio;
import com.proyect1.demo.Servicios.EditorialServicio;
import com.proyect1.demo.Servicios.LibroServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/")
public class PortalControlador {

    @Autowired
    AutorServicio ServAut;
    @Autowired
    EditorialServicio EdSer;
    @Autowired
    LibroServicio Ls;

    @GetMapping("/")
    public String libro() {
        return "Libros.html";
    }

    @GetMapping("/buscar")
    public String Buscar() {
        return "LibrosBuscar.html";
    }

    @GetMapping("/crear")
    public String Crear() {
        return "LibrosCrear.html";
    }

    @GetMapping("/autor")
    public String Autor() {
        return "Autor.html";
    }

    @PostMapping("/autor")
    public String Autor(ModelMap modelo, @RequestParam String nombre) {
        try {
            ServAut.CrearAutor(nombre);
            modelo.put("Exito", "Autor cargado correctamente");
            return "Autor.html";
        } catch (Exception e) {
            modelo.put("Error", e.getMessage());
            modelo.put("nombre", nombre);
            return "Autor.html";
        }

    }

    @PostMapping("/crear")
    public String LibrosCrear(ModelMap modelo, @RequestParam String Titulo, @RequestParam Integer anio, @RequestParam Long isbn, @RequestParam Integer ejemplares, @RequestParam Integer ejemplaresprestados) {
        try {
            /*Ls.CrearLibro(Titulo);
            Ls.CrearLibro(anio);*/
            modelo.put("Exito", "Libro cargado correctamente");
            return "LibrosCrear.html";
        } catch (Exception e) {
            modelo.put("Error", e.getMessage());
            modelo.put("Titulo",Titulo);
           
            return "LibrosCrear.html";
        }
    }
}

