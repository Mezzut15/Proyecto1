package com.proyect1.demo.Servicios;



import com.proyect1.demo.Entidades.Autor;
import com.proyect1.demo.Errores.erroresServicios;
import com.proyect1.demo.Repositorios.AutorRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service 
public class AutorServicio {
 
    @Autowired
   AutorRepositorio repAutor;

   
    
   public void CrearAutor(String nombre) throws  Exception {  
    Autor autor = new Autor();
   
    if (nombre == null || nombre.isEmpty()){
        throw new erroresServicios("El nombre del autor no es valido o esta vacio");
    } else{
        autor.setNombre(nombre);
        autor.setAlta(Boolean.TRUE);
        
        repAutor.save(autor);
    }
}
   public void ModificarAutor(String idAutor,  String nombre) throws  Exception{
       Autor autor = repAutor.findById(idAutor).get();
        if (nombre == null || nombre.isEmpty()){
        throw new erroresServicios("El nombre no se encuentra en la lista");
    } else{
        autor.setNombre(nombre);
        autor.setAlta(Boolean.TRUE);
        
        repAutor.save(autor);
    }
   }
    public void eliminarAutor(String idAutor) throws  Exception{
       Autor autor = repAutor.findById(idAutor).get();
        if ( autor == null){
        throw new erroresServicios("el nombre no se encuentra en la lista");
    } else{
        repAutor.save(autor);
    }
   }
}