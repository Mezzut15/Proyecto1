package com.proyect1.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibroTests {

	@Test
	void contextLoads() {
	}

}
